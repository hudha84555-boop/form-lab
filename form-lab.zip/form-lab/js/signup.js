// ===== Data =====
const takenUsernames = ["admin", "nimali", "kavin"];   // pretend the server sent these 
 
// ===== Page elements ===== 
const form = document.getElementById("signup-form"); 
const username = document.getElementById("username"); 
const email = document.getElementById("email"); 
const password = document.getElementById("password"); 
const confirmBox = document.getElementById("confirm"); 
const terms = document.getElementById("terms"); 
const showBtn = document.getElementById("show-btn"); 
const submitBtn = document.getElementById("submit-btn"); 
const result = document.getElementById("result"); 
const ruleItems = { 
  length: document.getElementById("rule-length"), 
  number: document.getElementById("rule-number"), 
  upper: document.getElementById("rule-upper"), 
  symbol: document.getElementById("rule-symbol") 
}; 
 
function showError(input, message) { 
  const errorEl = document.getElementById(`${input.id}-error`); 
  errorEl.textContent = message; 
  input.classList.toggle("invalid", message !== ""); 
  input.setAttribute("aria-invalid", message !== ""); 
} 
 
// TODO 1: Return "" if the username is valid, otherwise a message:
//   - 3 to 15 letters, numbers or _ only   (hint: /^\w{3,15}$/) 
//       -> "Use 3 to 15 letters, numbers or _." 
//   - not in takenUsernames, ignoring capitals (hint: toLowerCase) 
//       -> "That username is taken. Try another." 
function checkUsername(value) { 
  // your code here 
} 
 
// TODO 2: Return "" or "Enter an email like name@example.com." 
function checkEmail(value) { 
  // your code here 
} 
 
// TODO 3: Test the four rules, add or remove the class "met" on each 
// rule's li (ruleItems.length, ruleItems.number …), and return true 
// only when all four pass. 
//   length: 8 or more    number: /\d/    upper: /[A-Z]/    symbol: /[^A-Za-z0-9]/ 
function checkPasswordRules(value) { 
  // your code here 
} 
 
// TODO 4: Return "Please type your password again." if confirm is empty, 
// "Passwords do not match." if it differs, otherwise "". 
function checkConfirm() { 
  // your code here 
} 
 
function updateForm() { 
  if (username.value !== "") showError(username, checkUsername(username.value)); 
  if (email.value !== "") showError(email, checkEmail(email.value)); 
  if (confirmBox.value !== "") showError(confirmBox, checkConfirm()); 
  const pwOk = checkPasswordRules(password.value); 
  const allOk = checkUsername(username.value) === "" && 
                checkEmail(email.value) === "" && 
                pwOk && checkConfirm() === "" && terms.checked; 
  submitBtn.disabled = !allOk; 
} 
 
[username, email, password, confirmBox, terms].forEach((el) => { 
  el.addEventListener("input", updateForm); 
}); 
 
// TODO 5: When showBtn is clicked, switch password.type between 
// "password" and "text", and the button's text between "Show" and "Hide". 
 
form.addEventListener("submit", (e) => { 
  e.preventDefault(); 
  updateForm(); 
  if (submitBtn.disabled) return; 
  result.textContent = `Welcome, ${username.value.trim()}! Your account is ready.`; 
  form.hidden = true; 
  form.reset(); 
});