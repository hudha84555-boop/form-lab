function checkUsername(value) {
  const v = value.trim();
  if (!/^\w{3,15}$/.test(v)) return "Use 3 to 15 letters, numbers or _.";
  if (takenUsernames.includes(v.toLowerCase())) return "That username is taken. Try another.";
  return "";
}

function checkEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())
    ? "" : "Enter an email like name@example.com.";
}

function checkPasswordRules(value) {
  const results = {
    length: value.length >= 8,
    number: /\d/.test(value),
    upper: /[A-Z]/.test(value),
    symbol: /[^A-Za-z0-9]/.test(value)
  };
  for (const key in results) {
    ruleItems[key].classList.toggle("met", results[key]);
  }
  return Object.values(results).every(Boolean);
}

function checkConfirm() {
  if (confirmBox.value === "") return "Please type your password again.";
  if (confirmBox.value !== password.value) return "Passwords do not match.";
  return "";
}
showBtn.addEventListener("click", () => {
  const hidden = password.type === "password";
  password.type = hidden ? "text" : "password";
  showBtn.textContent = hidden ? "Hide" : "Show";
});
