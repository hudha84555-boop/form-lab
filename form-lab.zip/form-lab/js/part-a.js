console.log("Forms lab ready");
const form = document.getElementById("reg-form"); 
 
form.addEventListener("submit", (e) => { 
  e.preventDefault();             // stay on this page 
  console.log("Form submitted"); 
}); 
 const nameInput = document.getElementById("full-name"); 
const guestsInput = document.getElementById("guests"); 
 
const name = nameInput.value.trim();          // remove spaces at both ends 
const guests = Number(guestsInput.value);     // "2" becomes 2 
 
const data = Object.fromEntries(new FormData(form)); 
console.log(data);   // { fullName: "Nimali Perera", workshop: "js", … }

//task A3
const status = document.getElementById("status");
const summary = document.getElementById("summary");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("full-name").value.trim();
  const sel = document.getElementById("workshop");
  const workshopText = sel.options[sel.selectedIndex].text;
  const session = document.querySelector('input[name="session"]:checked').value;
  const guests = Number(document.getElementById("guests").value);
  const laptop = document.getElementById("laptop").checked;

  summary.textContent = "";
  const h2 = document.createElement("h2");
  h2.textContent = "Registration received";
  const ul = document.createElement("ul");
  [`Name: ${name}`, `Workshop: ${workshopText}`, `Session: ${session}`,
   `Guests: ${guests}`, `Own laptop: ${laptop ? "Yes" : "No"}`].forEach((t) => {
    const li = document.createElement("li");
    li.textContent = t;
    ul.append(li);
  });
  summary.append(h2, ul);

  status.textContent = `Thank you, ${name}!`;
  console.log(Object.fromEntries(new FormData(form)));
  form.reset();
});