//task B2
const form = document.getElementById("reg-form");
const statusMsg = document.getElementById("status");

function validateStudentId(v) {
  return /^HD\d-\d{3}$/.test(v) ? "" : "Use the format HD3-017.";
}
function validateEmail(v) {
  if (v.trim() === "") return "Please enter your email.";
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? "" : "Enter an email like name@example.com.";
}
function validatePhone(v) {
  return /^07\d{8}$/.test(v) ? "" : "Enter 10 digits starting with 07, e.g. 0771234567.";
}
function validateWorkshop(v) {
  return v !== "" ? "" : "Please choose a workshop.";
}
function validateGuests(v) {
  const n = Number(v);
  return v.trim() !== "" && Number.isInteger(n) && n >= 0 && n <= 3
    ? "" : "Guests must be a whole number from 0 to 3.";
}
